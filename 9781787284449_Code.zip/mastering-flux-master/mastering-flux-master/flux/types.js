export const ADD_TASK = 'addTask';
export const INIT_TASKS = 'initTasks';
export const REMOVED = 'removed';